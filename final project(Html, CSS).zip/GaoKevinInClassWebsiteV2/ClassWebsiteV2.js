/*Kevin Gao*/
function todaysDate() {
	var rightNow2 = new Date();
	var theMonth = 0, todaysDate = "";
	theMonth = rightNow2.toLocaleString('default', { month: 'long' });
	todaysDate = theMonth + " " + rightNow2.getDate()
		+ ',' + rightNow2.getFullYear();
	document.getElementById("showDate").innerHTML = todaysDate;
}
function myFunction() {
	window.scrollTo(0, 0);
}

function changeStyle(styleChoice) {
	if (styleChoice == "style#1_dotted") {
		document.getElementById("tableChangeColor").style.color = "green";
		document.getElementById("tableChangeColor").style.borderWidth = "0.3em";
		document.getElementById("tableChangeColor").style.borderStyle = "dotted";
		document.getElementById("tableChangeColor").style.borderColor = "yellow";

	}
	else if (styleChoice == "style#2_dashed") {
		document.getElementById("tableChangeColor").style.color = "green";
		document.getElementById("tableChangeColor").style.borderWidth = "0.3em";
		document.getElementById("tableChangeColor").style.borderStyle = "dashed";
		document.getElementById("tableChangeColor").style.borderColor = "yellow";

	}
	else if (styleChoice == "style#3_groove") {
		document.getElementById("tableChangeColor").style.color = "green";
		document.getElementById("tableChangeColor").style.borderWidth = "0.3em";
		document.getElementById("tableChangeColor").style.borderStyle = "groove";
		document.getElementById("tableChangeColor").style.borderColor = "yellow";

	}
	else if (styleChoice == "style#4_ridge") {
		document.getElementById("tableChangeColor").style.color = "green";
		document.getElementById("tableChangeColor").style.borderWidth = "0.3em";
		document.getElementById("tableChangeColor").style.borderStyle = "ridge";
		document.getElementById("tableChangeColor").style.borderColor = "yellow";

	}
	else if (styleChoice == "style#5_hidden") {
		document.getElementById("tableChangeColor").style.color = "green";
		document.getElementById("tableChangeColor").style.borderWidth = "0.3em";
		document.getElementById("tableChangeColor").style.borderStyle = "hidden";
		document.getElementById("tableChangeColor").style.borderColor = "yellow";

	}
	else if (styleChoice == "style#6_solid") {
		document.getElementById("tableChangeColor").style.color = "green";
		document.getElementById("tableChangeColor").style.borderWidth = "0.3em";
		document.getElementById("tableChangeColor").style.borderStyle = "solid";
		document.getElementById("tableChangeColor").style.borderColor = "yellow";

	}
	else if (styleChoice == "style#7_double") {
		document.getElementById("tableChangeColor").style.color = "green";
		document.getElementById("tableChangeColor").style.borderWidth = "0.3em";
		document.getElementById("tableChangeColor").style.borderStyle = "double";
		document.getElementById("tableChangeColor").style.borderColor = "yellow";

	}

}


